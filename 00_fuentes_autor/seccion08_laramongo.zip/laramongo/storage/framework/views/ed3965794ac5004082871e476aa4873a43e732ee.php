

<?php $__env->startSection('content'); ?>

    <div class="card mt-4">
        <div class="card-header">
            Crear libro
        </div>
        <div class="card-body">

            <?php echo $__env->make('dashboard.partials.errors-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form action="<?php echo e(route('book.store')); ?>" method="post">

                <?php echo $__env->make('dashboard.book._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <input type="submit" value="Enviar" class="mt-3 btn btn-success">

            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laramongo\resources\views/dashboard/book/create.blade.php ENDPATH**/ ?>