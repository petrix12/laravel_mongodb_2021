

<?php $__env->startSection('content'); ?>

    <div class="card mt-4">
        <div class="card-header">
            Editar libro: <?php echo e($category->title); ?>

        </div>
        <div class="card-body">

            <?php echo $__env->make('dashboard.partials.errors-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form action="<?php echo e(route('category.update',$category->_id)); ?>" method="post">
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('dashboard.category._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <input type="submit" value="Actualizar" class="mt-3 btn btn-success">

            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laramongo\resources\views/dashboard/category/edit.blade.php ENDPATH**/ ?>