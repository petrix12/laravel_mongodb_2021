<?php echo csrf_field(); ?>

<label for="title">Título</label>
<input name="title" id="title" type="text" class="form-control" value="<?php echo e(old('title', $category->title)); ?>">
<?php /**PATH C:\laragon\www\laramongo\resources\views/dashboard/category/_form.blade.php ENDPATH**/ ?>