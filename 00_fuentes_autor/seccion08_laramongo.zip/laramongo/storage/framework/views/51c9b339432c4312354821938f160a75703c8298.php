<?php if(session('status')): ?>
    
    <div class="alert alert-success my-2">
        <?php echo e(session('status')); ?>

    </div>

<?php endif; ?><?php /**PATH C:\laragon\www\laramongo\resources\views/dashboard/partials/alert-message.blade.php ENDPATH**/ ?>