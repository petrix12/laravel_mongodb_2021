<?php echo csrf_field(); ?>

<label for="title">Título</label>
<input name="title" id="title" type="text" class="form-control" value="<?php echo e(old('title', $book->title)); ?>">

<label for="age">Año</label>
<input name="age" id="age" type="numeric" class="form-control" value="<?php echo e(old('age', $book->age)); ?>">

<label for="description">Descripción</label>

<textarea id="description" name="description" class="form-control">
<?php echo e(old('description', $book->description)); ?>

</textarea>
<?php /**PATH C:\laragon\www\laramongo\resources\views/dashboard/book/_form.blade.php ENDPATH**/ ?>