<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

</head>
<body>

    <?php echo $__env->make('dashboard.partials.nav-header-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">

        <?php echo $__env->make('dashboard.partials.alert-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    
</body>
</html><?php /**PATH C:\laragon\www\laramongo\resources\views/dashboard/master.blade.php ENDPATH**/ ?>